/**
 * 
 */
/**
 * 
 */
module Diamond {
}