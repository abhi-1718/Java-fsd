/**
 * 
 */
/**
 * 
 */
module CollectionJava {
}