package facebook_testng;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class logintesting {
	
	WebDriver driver;
	@Test
	public void facebook() throws InterruptedException {
	driver.get("https://www.facebook.com/");
	
	//For Maximizing the screen
	driver.manage().window().maximize();
	
	//Entering E-Mail
	driver.findElement(By.id("email")).sendKeys("abhisekdhal20@gmail.com");
	Thread.sleep(3000);
	
	//Entering Password
	driver.findElement(By.id("pass")).sendKeys("teamtonystark");
	Thread.sleep(3000);
	
	
	//submit
	driver.findElement(By.name("login")).submit();
	}
	@BeforeMethod
	public void beforeMethod() {
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\abhis\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
	driver= new ChromeDriver();
	}
	@AfterMethod
	public void afterMethod() {
	//driver.close();
	driver=null;
	}

}
