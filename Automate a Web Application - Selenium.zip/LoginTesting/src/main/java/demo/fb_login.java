package demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class fb_login {

	public static void main(String[] args) throws Throwable {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\Users\\abhis\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe ");
         WebDriver driver = new ChromeDriver();
         driver.get("https://www.instagram.com/");
         
         //maximize window
        driver.manage().window().maximize();
        
        driver.findElement(By.name("username")).sendKeys("imrealabhisek");
        Thread.sleep(3000);
        driver.findElement(By.name("password")).sendKeys("977689");
        Thread.sleep(3000);
        WebElement login = driver.findElement(By.xpath("//button[@type='submit']"));
        login.click();
        
	}

}
