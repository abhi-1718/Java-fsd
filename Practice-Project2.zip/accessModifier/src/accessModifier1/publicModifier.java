package accessModifier1;
import accessModifier.*;

public class publicModifier {
public static void main(String[] args) {
		
	publicspecifiers obj = new publicspecifiers(); 
        obj.display();  
		
	}
}

