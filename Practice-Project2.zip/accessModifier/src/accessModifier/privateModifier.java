package accessModifier;
class privatemodi 
{ 
   private void display() 
    { 
        System.out.println("This is private access modifier"); 
    } 
} 
public class privateModifier {
	public static void main(String[] args) {
	
		System.out.println("Private Access modifier");
		privatemodi  obj = new privatemodi(); 

	}
}

