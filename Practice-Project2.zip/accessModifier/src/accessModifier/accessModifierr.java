package accessModifier;
class defAccessSpecifier
{ 
  void display() 
     { 
         System.out.println("This is default access modifier "); 
     } 
} 
public class accessModifierr {
	public static void main(String[] args) {
		//default
		System.out.println("Default Access Modifier");
		defAccessSpecifier obj = new defAccessSpecifier(); 		  
        obj.display(); 
    }
}

