package accessModifier;
class protectedmodi {
    // protected method
    protected void display() {
        System.out.println("This is Protected modifier");
    }
}
    class protectedModifier extends protectedmodi {
    	public static void main(String[] args) {
    		protectedModifier pro = new protectedModifier();
    	         // access protected method
    	        pro.display();
    	}

      }
