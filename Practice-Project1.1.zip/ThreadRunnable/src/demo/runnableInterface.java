package demo;
class myThread1 implements Runnable{
	public void run() {
		for (int i=0; i<5;i++) {
		System.out.println("Child Thread");
		}
	}
}
public class runnableInterface {
	public static void main(String args[]) {
		myThread1 myt = new myThread1()
;
		Thread t = new Thread(myt);
		t.run();
		for(int i=0; i<5; i++) {
			System.out.println("Main Threas");
		}
		}

}
