package demo;

public class exceptionHandling {
           public static void main(String[] args) {
	        try {
	            int result = divide(38, 0);
	            System.out.println("Result: " + result);
	        } catch (ArithmeticException e) {
	            System.out.println("Division by zero is not possible");
	        } finally {
	            System.out.println("Finally block will execute.");
	        }
	        System.out.println("Continues after exception handling.");
	    }
	    private static int divide(int a, int b) { //Throw Exception
	        return a / b;
	    }
	}
