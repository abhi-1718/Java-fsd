package demo;

public class callMethod {
	public int addnum(int a,int b) {
		int c=a+b;
		return c;
	}

	public static void main(String[] args) {

		callMethod b=new callMethod();
		int ans= b.addnum(80,54);
		System.out.println("Addition Of Two Number is :"+ans);
		}
}
