package demo;

public class callValue {
	    static int a = 20;
	    public static void main(String [] args) {           
	       int b = 30;
	       System.out.println("Before method call, a = "+a+ ", b = "+b);
	       changeValues(a,b);
	       System.out.println("After method call, a = "+a+ ", b = "+b);
	     }      
	    public static void changeValues(int p, int q) {      
	       p = 40;
	       q = 50;
	       System.out.println("In changeValues method, a = " +a+ ", p = "+p+", q = "+q);
	     }      
	  }
