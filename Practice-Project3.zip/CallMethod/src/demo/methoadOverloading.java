package demo;

public class methoadOverloading {
	public void area(int a)
    {
         System.out.println("Area of Cube : "+(6*a*a));
    }
    public void area1(int l,int w) 
    {
         System.out.println("Area of Rectangle : "+(l*w));
    }

    public static void main(String args[])
   {

       methoadOverloading ob=new methoadOverloading();
       ob.area(7);
       ob.area1(9,5);  
   }
}