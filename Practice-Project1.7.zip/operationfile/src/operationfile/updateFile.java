package operationfile;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class updateFile {
	 public static void main(String[] args) {
	        String fileName = "my_new_file.txt"; // Replace with the actual file name
	        String oldLine = "old content";
	        String newLine = "new content";

	        try (BufferedReader reader = new BufferedReader(new FileReader(fileName));
	             BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true))) { // Append mode
	            String line;
	            boolean found = false;

	            while ((line = reader.readLine()) != null) {
	                if (line.equals(oldLine)) {
	                    found = true;
	                    writer.write(newLine);
	                    writer.newLine(); // Add a newline for readability
	                } else {
	                    writer.write(line);
	                    writer.newLine();
	                }
	            }

	            if (!found) { // If the old line wasn't found, append the new line at the end
	                writer.write(newLine);
	                writer.newLine();
	            }
	        } catch (IOException e) {
	            System.out.println("Error updating file: " + e.getMessage());
	        }
	        System.out.println("DONE");
	    }
	}

