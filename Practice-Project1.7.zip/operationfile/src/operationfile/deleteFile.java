package operationfile;
import java.io.File;

public class deleteFile {
    public static void main(String[] args) {
        String fileName = "my_new_file.txt"; // Replace with the actual file name

        File file = new File(fileName);

        if (file.exists()) {
            if (file.delete()) {
                System.out.println("File deleted successfully: " + fileName);
            } else {
                System.out.println("Error deleting file: " + fileName);
            }
        } else {
            System.out.println("File not found: " + fileName);
        }
    }
}


