package operationfile;
import java.io.File;
import java.io.IOException;

public class createFile {
	 public static void main(String[] args) {
	        String fileName = "my_new_file.txt"; // Desired file name
	        String fileContent = "This is the content of the new file."; // Content to write

	        // Create a File object representing the new file
	        File file = new File(fileName);

	        try {
	            // Create the file if it doesn't exist
	            if (!file.exists()) {
	                file.createNewFile();
	                System.out.println("File created successfully: " + file.getName());
	            } else {
	                System.out.println("File already exists: " + file.getName());
	            }

	            // Optionally, write content to the file
	            if (!fileContent.isEmpty()) {
	                java.io.FileWriter writer = new java.io.FileWriter(file);
	                writer.write(fileContent);
	                writer.close();
	                System.out.println("Content written to file successfully.");
	            }
	        } catch (IOException e) {
	            System.out.println("Error creating or writing to file: " + e.getMessage());
	        }
	    }
	}
