package com.ecommercee.entity;

public class Eproduct {

}
