package oopsjava;
class Animal{
    protected String name;

    public Animal(String name)
    {
        this.name = name;
    }

    public void bark() {
    	 System.out.println(name + " is barking.");
	}

	public void eat()
    {
        System.out.println(name + " is eating.");
    }

    public void
 
sleep()
 
{
        System.out.println(name + " is sleeping.");
    }
}

class Dog extends Animal
 
{
    public Dog(String name) {
        super(name); // Call the parent constructor
    }

    @Override
    public void bark() {
        System.out.println(name + " is barking.");
    }
}

class Bird extends Animal {
    public Bird(String name) {
        super(name);
    }

    public void fly() {
        System.out.println(name + " is flying.");
    }
}

public class inheritanceJava {
	public static void main(String[] args) {
        Animal animal1 = new Animal("Tiger");
        Dog dog1 = new Dog("Tommy");
        Bird bird1 = new Bird("Carry");

        animal1.eat();
        dog1.eat();
        dog1.bark();
        bird1.eat();
        bird1.fly();
    }
}
