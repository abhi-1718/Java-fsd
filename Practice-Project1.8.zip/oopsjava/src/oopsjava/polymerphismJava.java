package oopsjava;

public class polymerphismJava {
	  public int mul(int x, int y) 
	    { 
	        return (x * y); 
	    } 
	    public int mul(int x, int y, int z) 
	    { 
	        return (x * y * z); 
	    } 
	    public double mul(double x, double y) 
	    { 
	        return (x * y); 
	    } 
	    public static void main(String args[]) 
	    { 
	    	polymerphismJava s = new polymerphismJava(); 
	        System.out.println(s.mul(10, 20)); 
	        System.out.println(s.mul(10, 20, 30)); 
	        System.out.println(s.mul(10.5, 20.5)); 
	    } 
	}