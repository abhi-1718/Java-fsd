package oopsjava;

public class classObject{
	 String name; 
	    String role; 
	    int age; 
	    String power; 
	    public classObject(String name, String role, int age, String power) 
	    { 
	        this.name = name; 
	        this.role= role; 
	        this.age = age; 
	        this.power = power; 
	    } 
	    public String getName() 
	    { 
	        return name; 
	    } 
	    public String getBreed() 
	    { 
	        return role; 
	    } 
	    public int getAge() 
	    { 
	        return age; 
	    } 
	    public String getColor() 
	    { 
	        return power; 
	    } 
	   
	    public String toString() 
	    { 
	        return("His name is "+ this.getName()+ ".\nHis role,age and power are " + this.getBreed()+", " + this.getAge()+ ", and "+ this.getColor() + "."); 
	    } 
	    public static void main(String[] args) 
	    { 
	    	classObject scott = new classObject("Steve Rogers","Leader",116, "Super Human Strength"); 
	        System.out.println(scott.toString()); 
	    } 
	}