package demo;
import java.util.regex.*;

public class RegularExp {
	public static void main(String args[]) 
    { 
        //define a pattern to be searched 
        Pattern pattern = Pattern.compile("Abhisek"); 
   
        // Search above pattern in "softwareTestingHelp.com" 
        Matcher m = pattern.matcher("My Name is Abhisek Dhal"); 
   
        // print the start and end position of the pattern found 
        while (m.find()) 
            System.out.println("Pattern found from position " + m.start() + 
                               " to " + (m.end()-1)); 
    } 
}

