package emo;

public class tryCatch {
	    public static void main(String[] args) {
	        try {
	            int[] numbers = new int[10];
	            System.out.println(numbers[20]); // ArrayIndexOutOfBoundsException
	            } 
	        catch (ArrayIndexOutOfBoundsException i) {
	            System.out.println("Error: Array index out of bounds!");
	            System.out.println("Details: " + i.getMessage());
	        } finally {
	            System.out.println("This code is always executed.");
	        }
	    }
	}
