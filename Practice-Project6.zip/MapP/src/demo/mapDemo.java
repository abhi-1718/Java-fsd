package demo;
import java.util.*;
public class mapDemo {

		public static void main(String[] args) {
			
			//Hashmap
			  HashMap<Integer,String> hmap=new HashMap<Integer,String>();      
		      hmap.put(1,"Steve");    
		      hmap.put(2,"Tony");    
		      hmap.put(3,"Thor");   
		       
		      System.out.println("\nThe elements of Hashmap are ");  
		      for(Map.Entry m:hmap.entrySet()){    
		       System.out.println(m.getKey()+" "+m.getValue());    
		      }
		      
		     //HashTable
		      Hashtable<Integer,String> htable=new Hashtable<Integer,String>();  
		      htable.put(4,"Natasha");  
		      htable.put(5,"Bruce");  
		      htable.put(6,"Clint");  
		      htable.put(7,"Peter");  

		      System.out.println("\nThe elements of HashTable are ");  
		      for(Map.Entry n:htable.entrySet()){    
		       System.out.println(n.getKey()+" "+n.getValue());    
		      }
		      
		      
		      //TreeMap
		      TreeMap<Integer,String> tmap=new TreeMap<Integer,String>();    
		      tmap.put(8,"Wanda");    
		      tmap.put(9,"Vision");    
		      tmap.put(10,"Scott");       
		      
		      System.out.println("\nThe elements of TreeMap are ");  
		      for(Map.Entry l:tmap.entrySet()){    
		       System.out.println(l.getKey()+" "+l.getValue());    
		      }    
		      
		   }  
	}

